import asyncio
import csv
import html as html_lib
import io
import json
import math
import os
import random
import re
import sqlite3
import string
import time
import traceback
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles

APP_DIR = Path(__file__).parent.resolve()
DATA_DIR = APP_DIR / "data"
STATIC_DIR = APP_DIR / "static"
DB_PATH = APP_DIR / "sonp.sqlite3"
TASKS_PATH = DATA_DIR / "tasks.json"

ALL_BLOCK_KEYS = [
    "cognitive_cards",
    "emp_motivation",
    "emp_communication",
    "emp_self_regulation",
    "emp_career_orientation",
    "emp_values",
    "emp_control",
    "legacy_math",
    "legacy_logic",
    "legacy_data",
    "legacy_misc",
]

LEGACY_CATEGORY_TO_BLOCK = {
    "Математика": "legacy_math",
    "Логика": "legacy_logic",
    "Анализ данных": "legacy_data",
    "Когнитивные карточки": "cognitive_cards",
}

ASSESSMENT_PRESETS = {
    "emp_core_plus_cards": {
        "cognitive_cards": True,
        "emp_motivation": True,
        "emp_communication": True,
        "emp_self_regulation": True,
        "emp_career_orientation": False,
        "emp_values": False,
        "emp_control": True,
        "legacy_math": False,
        "legacy_logic": False,
        "legacy_data": False,
        "legacy_misc": False,
    },
    "cards_only": {
        "cognitive_cards": True,
        "emp_motivation": False,
        "emp_communication": False,
        "emp_self_regulation": False,
        "emp_career_orientation": False,
        "emp_values": False,
        "emp_control": False,
        "legacy_math": False,
        "legacy_logic": False,
        "legacy_data": False,
        "legacy_misc": False,
    },
    "emp_full": {
        "cognitive_cards": True,
        "emp_motivation": True,
        "emp_communication": True,
        "emp_self_regulation": True,
        "emp_career_orientation": True,
        "emp_values": True,
        "emp_control": True,
        "legacy_math": False,
        "legacy_logic": False,
        "legacy_data": False,
        "legacy_misc": False,
    },
    "emp_full_all_cards_controls": {
        "cognitive_cards": True,
        "emp_motivation": True,
        "emp_communication": True,
        "emp_self_regulation": True,
        "emp_career_orientation": True,
        "emp_values": True,
        "emp_control": True,
        "legacy_math": False,
        "legacy_logic": False,
        "legacy_data": False,
        "legacy_misc": False,
    },
    "legacy": {
        "cognitive_cards": True,
        "emp_motivation": False,
        "emp_communication": False,
        "emp_self_regulation": False,
        "emp_career_orientation": False,
        "emp_values": False,
        "emp_control": False,
        "legacy_math": True,
        "legacy_logic": True,
        "legacy_data": True,
        "legacy_misc": True,
    },
    "custom": {key: False for key in ALL_BLOCK_KEYS},
}

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(STATIC_DIR, exist_ok=True)


# ====================== HELPERS ======================
def normalize_block_name(value: Optional[str]) -> str:
    s = str(value or "").strip()
    return s if s in ALL_BLOCK_KEYS else "legacy_misc"


def default_block_for(category: str, mode: str = "base") -> str:
    if mode == "card":
        return "cognitive_cards"
    if "контроль" in category.lower():
        return "emp_control"
    return LEGACY_CATEGORY_TO_BLOCK.get(category, "legacy_misc")


def sanitize_block_config(raw: Optional[dict], *, fallback_mode: str = "legacy") -> Dict[str, bool]:
    base = dict(ASSESSMENT_PRESETS.get(fallback_mode, ASSESSMENT_PRESETS["legacy"]))
    if isinstance(raw, dict):
        for key in ALL_BLOCK_KEYS:
            if key in raw:
                base[key] = bool(raw.get(key))
    return base


def resolve_assessment_mode(mode: Optional[str], legacy_filter_mode: Optional[str] = None) -> str:
    mode = str(mode or "").strip()
    if mode in ASSESSMENT_PRESETS:
        return mode
    legacy_filter_mode = str(legacy_filter_mode or "").strip()
    if legacy_filter_mode == "cards_only":
        return "cards_only"
    if legacy_filter_mode in ("all", "no_cards"):
        return "legacy"
    return "emp_core_plus_cards"


def infer_response_model(q: dict) -> str:
    raw = str(q.get("responseModel") or q.get("scoreMode") or "").strip().lower()
    if raw == "survey":
        return "survey"
    if str(q.get("mode", "base")) == "survey":
        return "survey"
    block = str(q.get("block", "")).strip()
    if block.startswith("emp_"):
        return "survey"
    return "quiz"


def task_block(q: dict) -> str:
    return normalize_block_name(q.get("block") or default_block_for(q.get("category", ""), q.get("mode", "base")))


def task_instrument(q: dict) -> str:
    return str(q.get("instrument") or q.get("subtype") or q.get("category") or "general")


def task_item_type(q: dict) -> str:
    if q.get("mode") == "card":
        return "cognitive_card"
    if infer_response_model(q) == "survey":
        return str(q.get("itemType") or "survey_item")
    return str(q.get("itemType") or "quiz_item")


def is_assessment_task(q: dict) -> bool:
    return infer_response_model(q) == "survey"


def is_card_task(q: dict) -> bool:
    return q.get("mode") == "card"


def is_control_task(q: dict) -> bool:
    block = task_block(q)
    if block == "emp_control":
        return True
    control_type = str(q.get("controlType") or "").strip().lower()
    if control_type and control_type not in {"none", "no", "false", "null", "regular"}:
        return True
    category = str(q.get("category") or "").lower()
    instrument = str(q.get("instrument") or "").lower()
    prompt = str(q.get("prompt") or q.get("title") or "").lower()
    markers = ["контроль", "внимательн", "social_desirability", "attention_check", "consistency_check"]
    text = " ".join([category, instrument, prompt])
    return any(marker in text for marker in markers)


def is_emp_content_task(q: dict) -> bool:
    return is_assessment_task(q) and not is_control_task(q)


def should_use_full_session_plan(mode: str) -> bool:
    return mode in {"cards_only", "emp_core_plus_cards", "emp_full", "emp_full_all_cards_controls"}


def compute_scored_value(q: dict, ans_text: str, ans_choice: Optional[int]) -> Optional[float]:
    if not is_assessment_task(q):
        return None
    if q.get("type") == "mcq":
        if ans_choice is None:
            return None
        option_scores = q.get("optionScores") or []
        if isinstance(option_scores, list) and 0 <= ans_choice < len(option_scores):
            try:
                value = float(option_scores[ans_choice])
                if q.get("reverse") and option_scores:
                    numeric = []
                    for item in option_scores:
                        try:
                            numeric.append(float(item))
                        except Exception:
                            pass
                    if numeric:
                        value = min(numeric) + max(numeric) - value
                return value
            except Exception:
                return None
        n = len(q.get("options") or [])
        if n <= 0:
            n = 5
        value = float(ans_choice + 1)
        if q.get("reverse"):
            value = float(n + 1) - value
        return value
    raw = (ans_text or "").strip().replace(",", ".")
    try:
        return float(raw)
    except Exception:
        return None


def _clone_shuffle(items: List[dict]) -> List[dict]:
    copied = list(items)
    random.shuffle(copied)
    return copied


def _round_robin_by_key(items: List[dict], key_fn) -> List[dict]:
    if not items:
        return []
    groups: Dict[str, List[dict]] = {}
    for item in items:
        groups.setdefault(str(key_fn(item)), []).append(item)
    for bucket in groups.values():
        random.shuffle(bucket)
    order = list(groups.keys())
    random.shuffle(order)
    result: List[dict] = []
    while order:
        next_order: List[str] = []
        for group_key in order:
            bucket = groups[group_key]
            if bucket:
                result.append(bucket.pop())
            if bucket:
                next_order.append(group_key)
        random.shuffle(next_order)
        order = next_order
    return result


def _interleave_even(primary: List[dict], inserts: List[dict]) -> List[dict]:
    if not primary:
        return list(inserts)
    if not inserts:
        return list(primary)

    gap_count = len(inserts) + 1
    base = len(primary) // gap_count
    extra = len(primary) % gap_count

    result: List[dict] = []
    idx = 0
    for gap in range(gap_count):
        take = base + (1 if gap < extra else 0)
        if take > 0:
            result.extend(primary[idx : idx + take])
            idx += take
        if gap < len(inserts):
            result.append(inserts[gap])
    return result


def _insert_evenly(base_items: List[dict], inserts: List[dict], *, avoid_edges: bool = True) -> List[dict]:
    if not inserts:
        return list(base_items)
    if not base_items:
        return list(inserts)

    result = list(base_items)
    original_len = len(base_items)
    offset = 0
    for idx, item in enumerate(inserts):
        raw_pos = round((idx + 1) * (original_len + 1) / (len(inserts) + 1))
        if avoid_edges:
            raw_pos = max(1, min(original_len - 1 if original_len > 1 else 1, raw_pos))
        insert_pos = max(0, min(len(result), raw_pos + offset))
        result.insert(insert_pos, item)
        offset += 1
    return result


def _collect_enabled_tasks(block_config: Dict[str, bool]) -> List[dict]:
    seen: set = set()
    items: List[dict] = []
    for q in _all_tasks():
        if q["id"] in seen:
            continue
        if not _allowed_by_block_config(q, block_config):
            continue
        seen.add(q["id"])
        items.append(q)
    return items


def build_session_plan(room: "Room") -> List[dict]:
    block_config = room.block_config or sanitize_block_config(None, fallback_mode=room.assessment_mode)
    enabled_tasks = _collect_enabled_tasks(block_config)

    cards = [q for q in enabled_tasks if is_card_task(q)]
    controls = [q for q in enabled_tasks if is_control_task(q)]
    emp_items = [q for q in enabled_tasks if is_emp_content_task(q)]
    others = [q for q in enabled_tasks if q not in cards and q not in controls and q not in emp_items]

    cards = _clone_shuffle(cards)
    controls = _clone_shuffle(controls)
    emp_items = _round_robin_by_key(emp_items, lambda q: task_block(q) or task_instrument(q))
    others = _round_robin_by_key(others, lambda q: q.get("category") or task_block(q))

    if room.assessment_mode == "cards_only":
        plan = cards
    else:
        primary: List[dict] = []
        if emp_items:
            primary.extend(emp_items)
        if others:
            if primary:
                primary = _insert_evenly(primary, others, avoid_edges=False)
            else:
                primary.extend(others)

        if primary and cards:
            plan = _interleave_even(primary, cards)
        elif primary:
            plan = primary
        elif cards:
            plan = cards
        else:
            plan = []

        if controls:
            plan = _insert_evenly(plan, controls, avoid_edges=True)

    if not plan:
        plan = _clone_shuffle(enabled_tasks)

    return plan


def normalize_expected_choice(value: Any) -> Any:
    if isinstance(value, list):
        return [normalize_expected_choice(v) for v in value]
    if isinstance(value, dict):
        return {str(k): normalize_expected_choice(v) for k, v in value.items()}
    return value


def evaluate_expected_choice(expected_choice: Any, actual_choice: Optional[int]) -> Optional[bool]:
    if expected_choice is None:
        return None
    if actual_choice is None:
        return False

    expected_choice = normalize_expected_choice(expected_choice)

    if isinstance(expected_choice, list):
        normalized: List[int] = []
        for item in expected_choice:
            try:
                normalized.append(int(item))
            except Exception:
                continue
        return actual_choice in normalized

    if isinstance(expected_choice, dict):
        if "anyOf" in expected_choice:
            return evaluate_expected_choice(expected_choice.get("anyOf"), actual_choice)
        if "allowed" in expected_choice:
            return evaluate_expected_choice(expected_choice.get("allowed"), actual_choice)
        try:
            low = int(expected_choice.get("min")) if expected_choice.get("min") is not None else None
            high = int(expected_choice.get("max")) if expected_choice.get("max") is not None else None
        except Exception:
            low = None
            high = None
        if low is not None and actual_choice < low:
            return False
        if high is not None and actual_choice > high:
            return False
        if low is not None or high is not None:
            return True
        return None

    try:
        return actual_choice == int(expected_choice)
    except Exception:
        return None


def compact_question_snapshot(q: dict) -> dict:
    snapshot = {
        "id": q.get("id"),
        "category": q.get("category"),
        "block": task_block(q),
        "instrument": task_instrument(q),
        "itemType": task_item_type(q),
        "responseModel": infer_response_model(q),
        "type": q.get("type"),
        "prompt": q.get("prompt"),
        "mode": q.get("mode", "base"),
        "subtype": q.get("subtype"),
        "difficulty": q.get("difficulty"),
        "timeRef": q.get("timeRef"),
        "tags": q.get("tags"),
        "controlType": q.get("controlType"),
        "expectedChoice": q.get("expectedChoice"),
        "scaleKey": q.get("scaleKey"),
        "reverse": q.get("reverse", False),
        "cardAxisWeights": q.get("cardAxisWeights"),
        "cardImage": q.get("cardImage"),
    }
    if q.get("type") == "mcq":
        snapshot["options"] = q.get("options", [])
        snapshot["correctIndex"] = q.get("correctIndex")
    else:
        snapshot["accept"] = q.get("accept", [])
    return snapshot


# ====================== DB ======================
def _has_column(cur: sqlite3.Cursor, table: str, column: str) -> bool:
    cur.execute(f"PRAGMA table_info('{table}')")
    cols = {row[1] for row in cur.fetchall()}
    return column in cols


def db_init():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    cur.execute(
        """
    CREATE TABLE IF NOT EXISTS rooms(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE,
        created_at INTEGER,
        rounds INTEGER,
        status TEXT,
        assessment_mode TEXT,
        block_config TEXT
    )"""
    )
    cur.execute(
        """
    CREATE TABLE IF NOT EXISTS players(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_code TEXT,
        player_id TEXT,
        name TEXT,
        score INTEGER DEFAULT 0
    )"""
    )
    cur.execute(
        """
    CREATE TABLE IF NOT EXISTS answers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_code TEXT,
        round_no INTEGER,
        question_id TEXT,
        category TEXT,
        block TEXT,
        instrument TEXT,
        item_type TEXT,
        player_id TEXT,
        player_name TEXT,
        answer_text TEXT,
        is_correct INTEGER,
        awarded INTEGER,
        scored_value REAL,
        time_spent_ms INTEGER
    )"""
    )
    cur.execute(
        """
    CREATE TABLE IF NOT EXISTS player_reports(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_code TEXT,
        player_id TEXT,
        player_name TEXT,
        overall_potential REAL,
        summary_text TEXT,
        fit_tags_json TEXT,
        strengths_json TEXT,
        growth_zones_json TEXT,
        recommendations_json TEXT,
        emp_radar_json TEXT,
        cognitive_radar_json TEXT,
        quality_json TEXT,
        game_metrics_json TEXT,
        profile_json TEXT,
        created_at INTEGER
    )"""
    )
    cur.execute(
        """
    CREATE TABLE IF NOT EXISTS room_reports(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_code TEXT UNIQUE,
        players_count INTEGER,
        avg_score REAL,
        avg_accuracy REAL,
        avg_potential REAL,
        top_tags_json TEXT,
        emp_radar_json TEXT,
        cognitive_radar_json TEXT,
        summary_json TEXT,
        dashboard_json TEXT,
        created_at INTEGER
    )"""
    )
    cur.execute(
        """
    CREATE TABLE IF NOT EXISTS round_questions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_code TEXT,
        round_no INTEGER,
        question_id TEXT,
        category TEXT,
        block TEXT,
        instrument TEXT,
        item_type TEXT,
        response_model TEXT,
        mode TEXT,
        subtype TEXT,
        question_meta TEXT
    )"""
    )
    cur.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_round_questions_room_round ON round_questions(room_code, round_no)")

    if not _has_column(cur, "players", "score"):
        cur.execute("ALTER TABLE players ADD COLUMN score INTEGER DEFAULT 0")

    if not _has_column(cur, "rooms", "status"):
        cur.execute("ALTER TABLE rooms ADD COLUMN status TEXT")
    if not _has_column(cur, "rooms", "assessment_mode"):
        cur.execute("ALTER TABLE rooms ADD COLUMN assessment_mode TEXT")
    if not _has_column(cur, "rooms", "block_config"):
        cur.execute("ALTER TABLE rooms ADD COLUMN block_config TEXT")

    if not _has_column(cur, "answers", "answer_choice"):
        cur.execute("ALTER TABLE answers ADD COLUMN answer_choice INTEGER")
    if not _has_column(cur, "answers", "block"):
        cur.execute("ALTER TABLE answers ADD COLUMN block TEXT")
    if not _has_column(cur, "answers", "instrument"):
        cur.execute("ALTER TABLE answers ADD COLUMN instrument TEXT")
    if not _has_column(cur, "answers", "item_type"):
        cur.execute("ALTER TABLE answers ADD COLUMN item_type TEXT")
    if not _has_column(cur, "answers", "scored_value"):
        cur.execute("ALTER TABLE answers ADD COLUMN scored_value REAL")
    if not _has_column(cur, "answers", "time_spent_ms"):
        cur.execute("ALTER TABLE answers ADD COLUMN time_spent_ms INTEGER")

    for column, ddl in [
        ("overall_potential", "REAL"),
        ("summary_text", "TEXT"),
        ("fit_tags_json", "TEXT"),
        ("strengths_json", "TEXT"),
        ("growth_zones_json", "TEXT"),
        ("recommendations_json", "TEXT"),
        ("emp_radar_json", "TEXT"),
        ("cognitive_radar_json", "TEXT"),
        ("quality_json", "TEXT"),
        ("game_metrics_json", "TEXT"),
    ]:
        if not _has_column(cur, "player_reports", column):
            cur.execute(f"ALTER TABLE player_reports ADD COLUMN {column} {ddl}")

    for column, ddl in [
        ("players_count", "INTEGER"),
        ("avg_score", "REAL"),
        ("avg_accuracy", "REAL"),
        ("avg_potential", "REAL"),
        ("top_tags_json", "TEXT"),
        ("emp_radar_json", "TEXT"),
        ("cognitive_radar_json", "TEXT"),
        ("summary_json", "TEXT"),
        ("dashboard_json", "TEXT"),
    ]:
        if not _has_column(cur, "room_reports", column):
            cur.execute(f"ALTER TABLE room_reports ADD COLUMN {column} {ddl}")

    for column, ddl in [
        ("response_model", "TEXT"),
        ("mode", "TEXT"),
        ("subtype", "TEXT"),
        ("question_meta", "TEXT"),
    ]:
        if not _has_column(cur, "round_questions", column):
            cur.execute(f"ALTER TABLE round_questions ADD COLUMN {column} {ddl}")

    con.commit()
    con.close()


def db_room_upsert(
    code: str,
    rounds: int,
    status: str,
    assessment_mode: str = "legacy",
    block_config: Optional[dict] = None,
):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    block_config_json = json.dumps(
        sanitize_block_config(block_config, fallback_mode=assessment_mode), ensure_ascii=False
    )
    cur.execute(
        "INSERT OR IGNORE INTO rooms(code, created_at, rounds, status, assessment_mode, block_config) VALUES(?,?,?,?,?,?)",
        (code, int(time.time()), rounds, status, assessment_mode, block_config_json),
    )
    cur.execute(
        "UPDATE rooms SET rounds=?, status=?, assessment_mode=?, block_config=? WHERE code=?",
        (rounds, status, assessment_mode, block_config_json, code),
    )
    con.commit()
    con.close()


def db_player_upsert(room_code: str, player_id: str, name: str, score: int):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute(
        """
        INSERT OR REPLACE INTO players(id, room_code, player_id, name, score)
        VALUES(
            COALESCE((SELECT id FROM players WHERE room_code=? AND player_id=?), NULL),
            ?,?,?,?
        )
    """,
        (room_code, player_id, room_code, player_id, name, score),
    )
    con.commit()
    con.close()


def db_answer_add(
    room_code,
    round_no,
    qid,
    category,
    block,
    instrument,
    item_type,
    player_id,
    player_name,
    text,
    choice,
    is_correct,
    awarded,
    scored_value,
    time_spent_ms,
):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute(
        """
        INSERT INTO answers(room_code, round_no, question_id, category, block, instrument, item_type, player_id, player_name,
                            answer_text, answer_choice, is_correct, awarded, scored_value, time_spent_ms)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """,
        (
            room_code,
            round_no,
            qid,
            category,
            block,
            instrument,
            item_type,
            player_id,
            player_name,
            text,
            None if choice is None else int(choice),
            None if is_correct is None else int(is_correct),
            awarded,
            scored_value,
            time_spent_ms,
        ),
    )
    con.commit()
    con.close()


def db_round_question_upsert(room_code: str, round_no: int, q: dict):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    snapshot = compact_question_snapshot(q)
    cur.execute(
        """
        INSERT INTO round_questions(
            room_code, round_no, question_id, category, block, instrument, item_type, response_model, mode, subtype, question_meta
        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(room_code, round_no) DO UPDATE SET
            question_id=excluded.question_id,
            category=excluded.category,
            block=excluded.block,
            instrument=excluded.instrument,
            item_type=excluded.item_type,
            response_model=excluded.response_model,
            mode=excluded.mode,
            subtype=excluded.subtype,
            question_meta=excluded.question_meta
    """,
        (
            room_code,
            round_no,
            q.get("id"),
            q.get("category"),
            task_block(q),
            task_instrument(q),
            task_item_type(q),
            infer_response_model(q),
            q.get("mode", "base"),
            q.get("subtype"),
            json.dumps(snapshot, ensure_ascii=False),
        ),
    )
    con.commit()
    con.close()


def db_player_report_upsert(room_code: str, player_id: str, player_name: str, profile: dict):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("DELETE FROM player_reports WHERE room_code=? AND player_id=?", (room_code, player_id))
    cur.execute(
        """
        INSERT INTO player_reports(
            room_code, player_id, player_name, overall_potential, summary_text, fit_tags_json,
            strengths_json, growth_zones_json, recommendations_json, emp_radar_json, cognitive_radar_json,
            quality_json, game_metrics_json, profile_json, created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """,
        (
            room_code,
            player_id,
            player_name,
            profile.get("overallPotential"),
            profile.get("summaryText"),
            json.dumps(profile.get("fitTags", []), ensure_ascii=False),
            json.dumps(profile.get("strengths", []), ensure_ascii=False),
            json.dumps(profile.get("growthZones", []), ensure_ascii=False),
            json.dumps(profile.get("recommendations", []), ensure_ascii=False),
            json.dumps(profile.get("empRadar", []), ensure_ascii=False),
            json.dumps(profile.get("cognitiveRadar", []), ensure_ascii=False),
            json.dumps(profile.get("quality", {}), ensure_ascii=False),
            json.dumps(profile.get("gameMetrics", {}), ensure_ascii=False),
            json.dumps(profile, ensure_ascii=False),
            int(time.time()),
        ),
    )
    con.commit()
    con.close()


def db_player_report_get(room_code: str, player_id: str) -> Optional[dict]:
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute(
        "SELECT profile_json FROM player_reports WHERE room_code=? AND player_id=? ORDER BY created_at DESC LIMIT 1",
        (room_code, player_id),
    )
    row = cur.fetchone()
    con.close()
    if not row or not row[0]:
        return None
    try:
        return json.loads(row[0])
    except Exception:
        return None


def db_all_player_reports(room_code: str) -> List[dict]:
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute(
        "SELECT profile_json FROM player_reports WHERE room_code=? ORDER BY overall_potential DESC, player_name ASC",
        (room_code,),
    )
    rows = cur.fetchall()
    con.close()
    out = []
    for row in rows:
        try:
            out.append(json.loads(row[0]))
        except Exception:
            continue
    return out


def db_room_report_upsert(room_code: str, dashboard: dict):
    summary = dashboard.get("summary", {})
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute(
        """
        INSERT INTO room_reports(
            room_code, players_count, avg_score, avg_accuracy, avg_potential, top_tags_json,
            emp_radar_json, cognitive_radar_json, summary_json, dashboard_json, created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(room_code) DO UPDATE SET
            players_count=excluded.players_count,
            avg_score=excluded.avg_score,
            avg_accuracy=excluded.avg_accuracy,
            avg_potential=excluded.avg_potential,
            top_tags_json=excluded.top_tags_json,
            emp_radar_json=excluded.emp_radar_json,
            cognitive_radar_json=excluded.cognitive_radar_json,
            summary_json=excluded.summary_json,
            dashboard_json=excluded.dashboard_json,
            created_at=excluded.created_at
    """,
        (
            room_code,
            summary.get("playersCount"),
            summary.get("avgScore"),
            summary.get("avgAccuracy"),
            summary.get("avgPotential"),
            json.dumps(summary.get("topTags", []), ensure_ascii=False),
            json.dumps((dashboard.get("roomRadar") or {}).get("emp", []), ensure_ascii=False),
            json.dumps((dashboard.get("roomRadar") or {}).get("cognitive", []), ensure_ascii=False),
            json.dumps(summary, ensure_ascii=False),
            json.dumps(dashboard, ensure_ascii=False),
            int(time.time()),
        ),
    )
    con.commit()
    con.close()


def db_room_report_get(room_code: str) -> Optional[dict]:
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("SELECT dashboard_json FROM room_reports WHERE room_code=?", (room_code,))
    row = cur.fetchone()
    con.close()
    if not row or not row[0]:
        return None
    try:
        return json.loads(row[0])
    except Exception:
        return None


def db_room_results(room_code: str):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("SELECT rounds, status, assessment_mode, block_config FROM rooms WHERE code=?", (room_code,))
    row = cur.fetchone()
    rounds = row[0] if row else 0
    status = row[1] if row else "unknown"
    assessment_mode = row[2] if row and row[2] else "legacy"
    try:
        block_config = (
            json.loads(row[3])
            if row and row[3]
            else sanitize_block_config(None, fallback_mode=assessment_mode)
        )
    except Exception:
        block_config = sanitize_block_config(None, fallback_mode=assessment_mode)

    cur.execute(
        """
        SELECT player_id, name, score FROM players
        WHERE room_code=?
        ORDER BY score DESC, name ASC
    """,
        (room_code,),
    )
    players = [{"playerId": r[0], "name": r[1], "score": r[2]} for r in cur.fetchall()]

    cur.execute(
        """
        SELECT round_no, question_id, category, block, instrument, item_type, player_id, player_name,
               answer_text, answer_choice, is_correct, awarded, scored_value, time_spent_ms
        FROM answers
        WHERE room_code=?
        ORDER BY round_no, player_name
    """,
        (room_code,),
    )
    answers = [
        {
            "round": r[0],
            "questionId": r[1],
            "category": r[2],
            "block": r[3],
            "instrument": r[4],
            "itemType": r[5],
            "playerId": r[6],
            "playerName": r[7],
            "text": r[8],
            "choice": r[9],
            "isCorrect": None if r[10] is None else bool(r[10]),
            "awarded": r[11],
            "scoredValue": r[12],
            "timeMs": r[13],
        }
        for r in cur.fetchall()
    ]

    cur.execute(
        """
        SELECT round_no, question_id, category, block, instrument, item_type, response_model, mode, subtype, question_meta
        FROM round_questions
        WHERE room_code=?
        ORDER BY round_no
    """,
        (room_code,),
    )
    round_questions = []
    for r in cur.fetchall():
        round_questions.append(
            {
                "round": r[0],
                "questionId": r[1],
                "category": r[2],
                "block": r[3],
                "instrument": r[4],
                "itemType": r[5],
                "responseModel": r[6],
                "mode": r[7],
                "subtype": r[8],
                "meta": _safe_json_loads(r[9], {}),
            }
        )
    con.close()
    return {
        "roomCode": room_code,
        "rounds": rounds,
        "status": status,
        "assessmentMode": assessment_mode,
        "blockConfig": block_config,
        "players": players,
        "answers": answers,
        "roundQuestions": round_questions,
    }


# ====================== TASKS ======================
def _normalize_answer(s: str) -> str:
    s = (s or "").strip()
    s = s.replace(",", ".")
    s = re.sub(r"\s+", " ", s)
    return s.lower()


def _is_correct_text(user_text: str, accepted: List[str]) -> bool:
    if not accepted:
        return False
    u = _normalize_answer(user_text)
    for a in accepted or []:
        if _normalize_answer(a) == u:
            return True
    try:
        au = _normalize_answer(accepted[0])
        return float(u) == float(au)
    except Exception:
        return False


WORD_LADDER_LISA_NORA_WORDS = {
    "ЛИСА", "ЛИЗА", "ЛИДА", "ЛИГА", "ЛИКА", "ЛИНА", "ЛИПА", "ЛИРА", "ЛИМА",
    "ЛАВА", "ЛАПА", "ЛЕВА", "ЛЕРА", "ЛОЗА", "ЛОРА", "ЛУНА", "ЛУПА",
    "ВЕРА", "ВИЛА", "ВИНА", "ВИРА",
    "ГОРА",
    "ДИРА", "ДОРА",
    "ЖИЛА",
    "ЗОНА",
    "КИРА", "КИСА", "КОСА", "КОЖА", "КОЗА", "КОРА", "КОТА",
    "МАРА", "МЕРА", "МИЛА", "МИНА", "МИРА", "МОДА", "МОРА", "МОНА",
    "НИВА", "НИНА", "НОВА", "НОГА", "НОРА", "НОСА", "НОТА", "НОША", "НОНА",
    "ПАРА", "ПОЗА", "ПОРА",
    "РОЗА",
    "СОРА",
    "ТАРА", "ТОРА",
    "ФОРА",
    "ШОРА",
}


def _letters_diff_one(a: str, b: str) -> bool:
    if len(a) != len(b):
        return False
    return sum(1 for x, y in zip(a, b) if x != y) == 1


def _extract_russian_words_4(ans_text: str) -> List[str]:
    if not ans_text:
        return []
    text = ans_text.upper().replace("Ё", "Е")
    return re.findall(r"[А-Я]{4}", text)


def _validate_word_ladder_lisa_nora(ans_text: str) -> Tuple[bool, str]:
    words = _extract_russian_words_4(ans_text)
    if not words:
        return False, "цепочка не распознана"
    if words[0] != "ЛИСА":
        return False, f"цепочка должна начинаться со слова «ЛИСА», а у вас «{words[0]}»"
    if words[-1] != "НОРА":
        return False, f"цепочка должна заканчиваться словом «НОРА», а у вас «{words[-1]}»"
    if len(words) < 5:
        return False, "цепочка слишком короткая"

    seen = set()
    for idx, word in enumerate(words, start=1):
        if word in seen:
            return False, f"слово «{word}» повторяется в шаге {idx}"
        seen.add(word)
        if word not in WORD_LADDER_LISA_NORA_WORDS:
            return False, f"слово «{word}» отсутствует в допустимом словаре"

    for prev, cur in zip(words, words[1:]):
        if not _letters_diff_one(prev, cur):
            return False, f"между словами «{prev}» и «{cur}» меняется не одна буква"

    return True, "цепочка принята"


def _check_word_ladder_lisa_nora(ans_text: str) -> bool:
    ok, _ = _validate_word_ladder_lisa_nora(ans_text)
    return ok


def _clock_numbers_layout() -> List[Tuple[int, float, float]]:
    nums: List[Tuple[int, float, float]] = []
    center_x = 115.0
    center_y = 115.0
    radius = 90.0
    for i in range(1, 13):
        angle = math.radians((i - 3) * 30)
        x = center_x + radius * math.cos(angle)
        y = center_y + radius * math.sin(angle)
        nums.append((i, x, y))
    return nums


CLOCK_NUMBERS_LAYOUT = _clock_numbers_layout()


def _compute_clock_sums_for_deg(deg: float) -> Tuple[int, int]:
    center_x = 115.0
    center_y = 115.0
    line_angle = math.radians(deg - 90.0)
    nx = -math.sin(line_angle)
    ny = math.cos(line_angle)

    s_a = 0
    s_b = 0
    for value, x, y in CLOCK_NUMBERS_LAYOUT:
        px = x - center_x
        py = y - center_y
        dot = px * nx + py * ny
        if dot > 0:
            s_a += value
        else:
            s_b += value
    return s_a, s_b


def _validate_clock_equal_sums(ans_text: str) -> Tuple[bool, str]:
    if not ans_text:
        return False, "ответ не получен"

    text = str(ans_text).strip()
    normalized = _normalize_answer(text)

    if normalized in {"39", "39.0", "39,0"}:
        return True, "верная общая сумма 39"

    sum_match = re.search(r"sum\s*=\s*(-?\d+(?:[.,]\d+)?)", text, flags=re.IGNORECASE)
    angle_match = re.search(r"angle\s*=\s*(-?\d+(?:[.,]\d+)?)", text, flags=re.IGNORECASE)
    sums_match = re.search(r"sums\s*=\s*(-?\d+)\s*,\s*(-?\d+)", text, flags=re.IGNORECASE)

    entered_sum: Optional[float] = None
    if sum_match:
        try:
            entered_sum = float(sum_match.group(1).replace(",", "."))
        except ValueError:
            return False, "не удалось распознать сумму"
    elif re.fullmatch(r"-?\d+(?:[.,]\d+)?", normalized):
        try:
            entered_sum = float(normalized.replace(",", "."))
        except ValueError:
            return False, "не удалось распознать сумму"

    if angle_match:
        try:
            deg = float(angle_match.group(1).replace(",", "."))
        except ValueError:
            return False, "не удалось распознать угол"

        s_a, s_b = _compute_clock_sums_for_deg(deg)
        if s_a != s_b:
            return False, f"при повороте {deg:g}° получаются суммы {s_a} и {s_b}, они не равны"

        if entered_sum is None:
            return False, f"линия стоит верно, но сумма не указана; правильная сумма {s_a}"

        if abs(entered_sum - s_a) > 1e-9:
            return False, f"линия стоит верно, но общая сумма должна быть {s_a:g}, а у вас {entered_sum:g}"

        return True, f"циферблат разделён верно, общая сумма {s_a:g}"

    if sums_match:
        try:
            s_a = int(sums_match.group(1))
            s_b = int(sums_match.group(2))
        except ValueError:
            return False, "не удалось распознать суммы по сторонам линии"

        if s_a != s_b:
            return False, f"по сторонам линии получаются суммы {s_a} и {s_b}, они не равны"

        if entered_sum is None:
            return True, f"линия делит циферблат на две равные части по {s_a}"

        if abs(entered_sum - s_a) > 1e-9:
            return False, f"линия делит циферблат верно, но нужно было указать сумму {s_a:g}, а у вас {entered_sum:g}"

        return True, f"циферблат разделён верно, общая сумма {s_a:g}"

    if entered_sum is not None:
        if abs(entered_sum - 39.0) <= 1e-9:
            return True, "верная общая сумма 39"
        return False, f"общая сумма должна быть 39, а у вас {entered_sum:g}"

    return False, "не удалось распознать ответ по циферблату"


def _check_clock_equal_sums(ans_text: str) -> bool:
    ok, _ = _validate_clock_equal_sums(ans_text)
    return ok


def _check_robot_pair_to_target(ans_text: str) -> bool:
    if not ans_text:
        return False
    nums = re.findall(r"-?\d+", ans_text)
    if len(nums) < 2:
        return False
    try:
        a = int(nums[0])
        b = int(nums[1])
    except ValueError:
        return False
    if a <= 0 or b <= 0:
        return False
    return (a * b - 5) == 72


def load_tasks_raw() -> dict:
    if not TASKS_PATH.exists():
        TASKS_PATH.write_text("{}", encoding="utf-8")
    try:
        with open(TASKS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


OPTIONAL_TASK_KEYS = [
    "subtype",
    "difficulty",
    "timeRef",
    "tags",
    "reverse",
    "scaleKey",
    "optionScores",
    "cardImage",
    "cardAxisWeights",
    "controlType",
    "expectedChoice",
]


def transform_tasks(raw: dict) -> Dict[str, List[dict]]:
    out: Dict[str, List[dict]] = {}
    id_counter = 1

    for category, arr in (raw or {}).items():
        if not isinstance(arr, list):
            continue
        out_list: List[dict] = []

        for q in arr:
            if not isinstance(q, dict):
                continue

            raw_mode = str(q.get("mode", "base")).strip() or "base"
            raw_block = normalize_block_name(q.get("block") or default_block_for(category, raw_mode))
            response_model = infer_response_model({**q, "block": raw_block})
            instrument = str(q.get("instrument") or q.get("subtype") or category).strip() or category
            item_type = str(
                q.get("itemType")
                or ("cognitive_card" if raw_mode == "card" else ("survey_item" if response_model == "survey" else "quiz_item"))
            ).strip()

            if "type" in q and "title" in q:
                qtype = q.get("type")
                if qtype not in ("mcq", "text"):
                    continue
                item = {
                    "id": q.get("id") or f"q{id_counter}",
                    "category": category,
                    "block": raw_block,
                    "instrument": instrument,
                    "itemType": item_type,
                    "responseModel": response_model,
                    "type": qtype,
                    "prompt": str(q.get("title", "")).strip(),
                    "mode": raw_mode,
                }
                id_counter += 1

                for key in OPTIONAL_TASK_KEYS:
                    if key in q:
                        item[key] = q[key]

                if qtype == "mcq":
                    opts = q.get("options") or []
                    if not opts:
                        continue
                    item["options"] = [str(x) for x in opts]
                    if q.get("correctIndex") is not None:
                        item["correctIndex"] = int(q.get("correctIndex"))
                        if "expectedChoice" not in item:
                            item["expectedChoice"] = int(q.get("correctIndex"))
                    elif response_model != "survey":
                        continue
                else:
                    acc = q.get("accept") or []
                    item["accept"] = [str(x) for x in acc]
                    if not item["accept"] and response_model != "survey":
                        continue
                out_list.append(item)
                continue

            if "prompt" in q and "answers" in q:
                item = {
                    "id": q.get("id") or f"q{id_counter}",
                    "category": category,
                    "block": raw_block,
                    "instrument": instrument,
                    "itemType": item_type,
                    "responseModel": response_model,
                    "type": "text",
                    "prompt": str(q.get("prompt", "")).strip(),
                    "accept": [str(x) for x in (q.get("answers") or [])],
                    "mode": raw_mode,
                }
                id_counter += 1
                for key in OPTIONAL_TASK_KEYS:
                    if key in q:
                        item[key] = q[key]
                if item["accept"] or response_model == "survey":
                    out_list.append(item)
                continue

        if out_list:
            out[category] = out_list

    return out


RAW_TASKS = load_tasks_raw()
TASK_BANK = transform_tasks(RAW_TASKS)
CATEGORIES = list(TASK_BANK.keys())
TASK_BY_ID = {q["id"]: q for q in TASK_BANK.values() for q in q}


def task_counts():
    total = 0
    per_cat: Dict[str, int] = {}
    per_block: Dict[str, int] = {}
    per_instrument: Dict[str, int] = {}
    for q in _all_tasks():
        total += 1
        per_cat[q["category"]] = per_cat.get(q["category"], 0) + 1
        b = task_block(q)
        per_block[b] = per_block.get(b, 0) + 1
        instr = task_instrument(q)
        per_instrument[instr] = per_instrument.get(instr, 0) + 1
    return {"total": total, "categories": per_cat, "blocks": per_block, "instruments": per_instrument}


def _all_tasks():
    for cat in CATEGORIES:
        for q in TASK_BANK.get(cat, []):
            yield q


def _allowed_by_block_config(q: dict, block_config: Optional[dict]) -> bool:
    if not block_config:
        return True
    return bool(block_config.get(task_block(q), False))


def pick_question(used_ids: set, desired_mode: Optional[str] = None, block_config: Optional[dict] = None) -> dict:
    candidates: List[dict] = []

    for cat in CATEGORIES:
        for q in TASK_BANK.get(cat, []):
            if q["id"] in used_ids:
                continue
            if not _allowed_by_block_config(q, block_config):
                continue
            mode = q.get("mode", "base")
            if desired_mode == "non_card" and mode == "card":
                continue
            if desired_mode not in (None, "non_card") and mode != desired_mode:
                continue
            candidates.append(q)

    if not candidates and desired_mode is not None:
        for cat in CATEGORIES:
            for q in TASK_BANK.get(cat, []):
                if q["id"] in used_ids:
                    continue
                if not _allowed_by_block_config(q, block_config):
                    continue
                candidates.append(q)

    if candidates:
        return random.choice(candidates)

    fallback_pool = [q for q in _all_tasks() if _allowed_by_block_config(q, block_config)]
    if fallback_pool:
        return random.choice(fallback_pool)

    if not CATEGORIES:
        return {
            "id": "none",
            "category": "N/A",
            "block": "legacy_misc",
            "instrument": "none",
            "itemType": "quiz_item",
            "responseModel": "quiz",
            "type": "text",
            "prompt": "(Нет задач)",
            "accept": [""],
            "mode": "base",
        }

    cat = random.choice(CATEGORIES)
    return random.choice(TASK_BANK[cat])


# ====================== ROOMS ======================
def gen_code() -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(random.choice(alphabet) for _ in range(4))


@dataclass
class PlayerConn:
    ws: WebSocket
    id: str
    name: str
    score: int = 0
    answered: bool = False
    ans_text: str = ""
    ans_choice: Optional[int] = None
    ans_time_ms: int = 0


@dataclass
class Room:
    code: str
    rounds: int = 6
    admin: Optional[WebSocket] = None
    players: Dict[str, PlayerConn] = field(default_factory=dict)
    status: str = "lobby"
    current_round: int = 0
    current_question: Optional[dict] = None
    used_ids: set = field(default_factory=set)
    round_deadline: float = 0.0
    time_limit: int = 0
    timer_task: Optional[asyncio.Task] = None
    assessment_mode: str = "legacy"
    block_config: Dict[str, bool] = field(default_factory=lambda: sanitize_block_config(None, fallback_mode="legacy"))
    session_plan: List[dict] = field(default_factory=list)

    def snapshot_players(self):
        return [{"playerId": p.id, "name": p.name, "score": p.score} for p in self.players.values()]


ROOMS: Dict[str, Room] = {}
CLIENT_TO_ROOM: Dict[WebSocket, str] = {}


EMP_RADAR_GROUPS = {
    "motivation": ("Мотивация", ["achievement_drive", "growth_orientation", "persistence", "failure_avoidance"], {"failure_avoidance"}),
    "communication": ("Коммуникация", ["communication", "empathy", "teamwork", "assertive_communication"], set()),
    "self_regulation": ("Саморегуляция", ["planning", "self_regulation", "adaptability", "self_control", "persistence"], set()),
    "it_career": ("ИТ-вектор", ["professional_orientation", "innovation_orientation", "it_orientation", "learning_value"], set()),
    "values": ("Ценности", ["meaning_orientation", "ethical_orientation", "responsibility", "respect_orientation", "team_values", "user_value_orientation"], set()),
    "stability": ("Рабочая устойчивость", ["stability_orientation", "adaptability", "self_control"], set()),
}

COGNITIVE_LABELS = {
    "numerical_reasoning": "Числовое мышление",
    "abstract_reasoning": "Абстрактное мышление",
    "planning": "Планирование",
    "spatial_reasoning": "Пространственное мышление",
    "verbal_reasoning": "Вербальная логика",
    "data_interpretation": "Интерпретация данных",
}

CATEGORY_FALLBACK_CARD_AXES = {
    "Математика": {"numerical_reasoning": 0.75, "planning": 0.25},
    "Логика": {"abstract_reasoning": 0.7, "verbal_reasoning": 0.3},
    "Анализ данных": {"data_interpretation": 0.7, "numerical_reasoning": 0.3},
}

RECOMMENDATION_LIBRARY = {
    "communication": "Комфортно проявляется в задачах, где нужно договариваться, уточнять требования и удерживать общий ритм команды.",
    "motivation": "Лучше всего раскрывается в среде с понятными целями, заметным прогрессом и регулярной обратной связью по результату.",
    "self_regulation": "Можно уверенно давать самостоятельные участки работы с дедлайнами, чек-листами и необходимостью доводить задачу до конца.",
    "it_career": "Есть хороший задел для включения в ИТ-задачи, где важны интерес к продукту, данным, новым инструментам и поиску решений.",
    "values": "Сильнее проявляется в командах с прозрачными правилами, уважительной коммуникацией и культурой ответственного взаимодействия.",
    "planning": "Подойдут задачи с декомпозицией, маршрутами решения, несколькими шагами и необходимостью заранее продумывать ход работы.",
    "numerical_reasoning": "Есть смысл подключать к задачам с расчётами, ограничениями, таблицами и проверкой гипотез на числовых данных.",
    "abstract_reasoning": "Хорошо включается в поиск закономерностей, нетривиальные правила, структурное рассуждение и формализацию идей.",
    "spatial_reasoning": "Подходит для визуально-пространственных задач, схем, сеток, маршрутов и мысленной перестройки объектов.",
    "data_interpretation": "Можно давать работу с графиками, аналитикой, метриками и объяснением динамики данных на понятном языке.",
}


def _safe_json_loads(value: Any, default: Any):
    if not value:
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value)
    except Exception:
        return default


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, float(value)))


def _mean(values: List[float], default: float = 0.0) -> float:
    nums = [float(v) for v in values if v is not None]
    if not nums:
        return float(default)
    return sum(nums) / len(nums)


def _normalize_likert_to_pct(value: Optional[float]) -> Optional[float]:
    if value is None:
        return None
    return _clamp(((float(value) - 1.0) / 4.0) * 100.0)


def _question_meta_map(room_results: dict) -> Dict[Tuple[int, str], dict]:
    meta_by_key: Dict[Tuple[int, str], dict] = {}
    for item in room_results.get("roundQuestions", []) or []:
        meta = item.get("meta") or {}
        snapshot = {**meta}
        snapshot.setdefault("id", item.get("questionId"))
        snapshot.setdefault("category", item.get("category"))
        snapshot.setdefault("block", item.get("block"))
        snapshot.setdefault("instrument", item.get("instrument"))
        snapshot.setdefault("itemType", item.get("itemType"))
        snapshot.setdefault("responseModel", item.get("responseModel"))
        snapshot.setdefault("mode", item.get("mode"))
        snapshot.setdefault("subtype", item.get("subtype"))
        meta_by_key[(item.get("round"), item.get("questionId"))] = snapshot
    for ans in room_results.get("answers", []) or []:
        key = (ans.get("round"), ans.get("questionId"))
        if key not in meta_by_key:
            q = TASK_BY_ID.get(ans.get("questionId"))
            if q:
                meta_by_key[key] = compact_question_snapshot(q)
            else:
                meta_by_key[key] = {
                    "id": ans.get("questionId"),
                    "category": ans.get("category"),
                    "block": ans.get("block"),
                    "instrument": ans.get("instrument"),
                    "itemType": ans.get("itemType"),
                    "responseModel": "survey" if str(ans.get("block") or "").startswith("emp_") else "quiz",
                    "mode": "base",
                }
    return meta_by_key


def _card_score(answer: dict, meta: dict) -> float:
    is_correct = bool(answer.get("isCorrect"))
    if answer.get("isCorrect") is None:
        is_correct = False
    base = 100.0 if is_correct else 0.0
    time_ref = meta.get("timeRef") or 0
    time_ms = answer.get("timeMs") or 0
    if time_ref and time_ms:
        speed = _clamp((float(time_ref) / max(float(time_ms) / 1000.0, 1.0)) * 100.0)
    else:
        speed = 0.0
    return base * 0.8 + speed * 0.2


def _flatten_tags(items: List[str]) -> str:
    return " | ".join([str(x) for x in items if x])


def _question_short(meta: dict) -> str:
    prompt = str(meta.get("prompt") or "").strip()
    return prompt if len(prompt) <= 140 else prompt[:137] + "..."


def finalize_weighted_axes(weighted_sum: Dict[str, float], weight_total: Dict[str, float]) -> Dict[str, float]:
    result: Dict[str, float] = {}
    for key, total in weighted_sum.items():
        w = float(weight_total.get(key, 0.0) or 0.0)
        if w > 0:
            result[key] = _clamp(total / w)
    return result


def profile_level_text(overall_potential: float) -> str:
    if overall_potential >= 80:
        return "высокий"
    if overall_potential >= 65:
        return "хороший"
    if overall_potential >= 50:
        return "умеренный"
    return "начальный"


def top_labels(items: List[dict], limit: int = 2) -> List[str]:
    seen = set()
    result: List[str] = []
    for item in sorted(items, key=lambda x: float(x.get("value", 0.0)), reverse=True):
        label = str(item.get("label") or "").strip()
        if not label or label in seen:
            continue
        seen.add(label)
        result.append(label)
        if len(result) >= limit:
            break
    return result


def build_player_badges(rank: Optional[int], overall_potential: float, cognitive_accuracy: float, speed_index: float, attention_pass_rate: float) -> List[str]:
    badges: List[str] = []
    if rank == 1:
        badges.append("🥇 1 место")
    elif rank == 2:
        badges.append("🥈 2 место")
    elif rank == 3:
        badges.append("🥉 3 место")
    elif rank is not None:
        badges.append(f"#{rank} место")

    if overall_potential >= 85:
        badges.append("🚀 Очень высокий потенциал")
    elif overall_potential >= 70:
        badges.append("🌟 Сильный потенциал")

    if cognitive_accuracy >= 95:
        badges.append("🎯 Почти без ошибок")
    elif cognitive_accuracy >= 80:
        badges.append("✅ Уверенная точность")

    if speed_index >= 85:
        badges.append("⚡ Молниеносный темп")
    elif speed_index >= 70:
        badges.append("🏃 Быстрый темп")

    if attention_pass_rate >= 100:
        badges.append("🧭 Идеальный контроль внимания")
    elif attention_pass_rate >= 80:
        badges.append("👀 Надёжное внимание")

    return badges


def _top_axis_keys(items: List[dict], threshold: float = 60.0) -> List[str]:
    keys: List[str] = []
    for item in sorted(items, key=lambda x: float(x.get("value", 0.0)), reverse=True):
        if float(item.get("value", 0.0)) < threshold:
            continue
        key = str(item.get("key") or "")
        if key and key not in keys:
            keys.append(key)
    return keys


def _build_player_report(player_row: dict, answers: List[dict], meta_by_key: Dict[Tuple[int, str], dict], rank_map: Dict[str, int]) -> dict:
    player_id = player_row.get("playerId")
    player_name = player_row.get("name")

    emp_weighted_sum: Dict[str, float] = defaultdict(float)
    emp_weight_total: Dict[str, float] = defaultdict(float)
    cog_weighted_sum: Dict[str, float] = defaultdict(float)
    cog_weight_total: Dict[str, float] = defaultdict(float)

    quality_attention: List[int] = []
    quality_desirability: List[float] = []
    cognitive_correct = 0
    cognitive_total = 0
    cognitive_time: List[float] = []
    speed_components: List[float] = []
    history_rows: List[dict] = []

    for ans in sorted(answers, key=lambda x: (x.get("round") or 0, x.get("playerName") or "")):
        meta = meta_by_key.get((ans.get("round"), ans.get("questionId")), {})
        response_model = meta.get("responseModel") or ("survey" if str(ans.get("block") or "").startswith("emp_") else "quiz")
        control = is_control_task(meta or ans)
        scored_value = ans.get("scoredValue")

        if response_model == "survey":
            scale_key = meta.get("scaleKey") or {}
            if control:
                ctype = str(meta.get("controlType") or meta.get("instrument") or ans.get("instrument") or "control").lower()
                if "attention" in ctype or "вним" in ctype:
                    quality_attention.append(1 if ans.get("isCorrect") else 0)
                if "social_desirability" in ctype or "desirability" in ctype:
                    desirability_pct = _normalize_likert_to_pct(scored_value)
                    if desirability_pct is not None:
                        quality_desirability.append(desirability_pct)
            else:
                for axis_key, weight in (scale_key or {}).items():
                    pct = _normalize_likert_to_pct(scored_value)
                    if pct is None:
                        continue
                    w = float(weight)
                    emp_weighted_sum[str(axis_key)] += w * pct
                    emp_weight_total[str(axis_key)] += w
        else:
            cognitive_total += 1
            if ans.get("isCorrect"):
                cognitive_correct += 1
            if ans.get("timeMs") is not None:
                cognitive_time.append(float(ans.get("timeMs")))
            time_ref = meta.get("timeRef") or 0
            if time_ref and ans.get("timeMs"):
                speed_components.append(_clamp((float(time_ref) / max(float(ans.get("timeMs")) / 1000.0, 1.0)) * 100.0))
            axis_weights = meta.get("cardAxisWeights") or CATEGORY_FALLBACK_CARD_AXES.get(meta.get("category"), {})
            perf = _card_score(ans, meta)
            for axis_key, weight in (axis_weights or {}).items():
                w = float(weight)
                cog_weighted_sum[str(axis_key)] += w * perf
                cog_weight_total[str(axis_key)] += w

        history_rows.append(
            {
                "round": ans.get("round"),
                "category": meta.get("category") or ans.get("category"),
                "block": meta.get("block") or ans.get("block"),
                "instrument": meta.get("instrument") or ans.get("instrument"),
                "prompt": meta.get("prompt") or "",
                "questionShort": _question_short(meta),
                "answer": ans.get("text") if ans.get("text") else ans.get("choice"),
                "isCorrect": ans.get("isCorrect"),
                "awarded": ans.get("awarded") or 0,
                "timeMs": ans.get("timeMs"),
                "responseModel": response_model,
                "statusText": "получен" if response_model == "survey" else ("верно" if ans.get("isCorrect") else "неверно"),
            }
        )

    emp_axes = finalize_weighted_axes(emp_weighted_sum, emp_weight_total)
    cog_axes = finalize_weighted_axes(cog_weighted_sum, cog_weight_total)

    emp_radar = []
    for radar_key, (label, axis_keys, invert_keys) in EMP_RADAR_GROUPS.items():
        vals = []
        for axis_key in axis_keys:
            if axis_key not in emp_axes:
                continue
            axis_val = emp_axes[axis_key]
            if axis_key in invert_keys:
                axis_val = 100.0 - axis_val
            vals.append(axis_val)
        emp_radar.append({"key": radar_key, "label": label, "value": round(_mean(vals, default=0.0), 1)})

    cognitive_radar = []
    for axis_key, label in COGNITIVE_LABELS.items():
        if axis_key in cog_axes:
            cognitive_radar.append({"key": axis_key, "label": label, "value": round(cog_axes[axis_key], 1)})

    cognitive_accuracy = round((cognitive_correct / cognitive_total) * 100.0, 1) if cognitive_total else 0.0
    avg_cognitive_time = round(_mean(cognitive_time, default=0.0), 1) if cognitive_time else 0.0
    speed_index = round(_mean(speed_components, default=0.0), 1) if speed_components else 0.0
    attention_pass_rate = round((sum(quality_attention) / len(quality_attention)) * 100.0, 1) if quality_attention else 100.0
    social_desirability_index = round(_mean(quality_desirability, default=25.0), 1) if quality_desirability else 25.0
    data_quality_index = round(_clamp(0.65 * attention_pass_rate + 0.35 * (100.0 - social_desirability_index)), 1)

    emp_core_values = []
    for axis_key, value in emp_axes.items():
        adjusted = 100.0 - value if axis_key == "failure_avoidance" else value
        emp_core_values.append(adjusted)
    emp_core = _mean(emp_core_values, default=55.0) if emp_core_values else 55.0
    cognitive_core = _mean([item["value"] for item in cognitive_radar], default=cognitive_accuracy if cognitive_total else 50.0)
    overall_potential = round(_clamp(0.55 * emp_core + 0.35 * cognitive_core + 0.10 * data_quality_index), 1)

    tag_candidates = []
    for item in sorted(emp_radar + cognitive_radar, key=lambda x: x.get("value", 0), reverse=True):
        if item.get("value", 0) >= 60:
            tag_candidates.append(item.get("label"))
    if speed_index >= 75:
        tag_candidates.append("Хороший темп")
    if attention_pass_rate >= 80:
        tag_candidates.append("Надёжные данные")

    fit_tags = []
    for tag in tag_candidates:
        if tag and tag not in fit_tags:
            fit_tags.append(tag)
        if len(fit_tags) >= 5:
            break
    if not fit_tags:
        fit_tags = ["Есть база для развития"]

    strength_candidates = [item["label"] for item in sorted(emp_radar + cognitive_radar, key=lambda x: x.get("value", 0), reverse=True) if item.get("value", 0) >= 65]
    growth_candidates = [item["label"] for item in sorted(emp_radar + cognitive_radar, key=lambda x: x.get("value", 0)) if item.get("value", 0) <= 45]
    strengths = strength_candidates[:4] or ["Профиль раскрывается через реальные кейсы, дедлайны и взаимодействие в команде"]
    growth_zones = growth_candidates[:4] or ["Критических провалов не выявлено; дальнейший рост лучше уточнять на практических задачах"]

    top_emp = top_labels(emp_radar, 2)
    top_cog = top_labels(cognitive_radar, 2)
    top_emp_keys = _top_axis_keys(emp_radar)
    top_cog_keys = _top_axis_keys(cognitive_radar)

    recommendations = []
    for axis_key in top_emp_keys + top_cog_keys:
        if axis_key in RECOMMENDATION_LIBRARY:
            text = RECOMMENDATION_LIBRARY[axis_key]
            if text not in recommendations:
                recommendations.append(text)
        if len(recommendations) >= 3:
            break
    if attention_pass_rate < 70:
        recommendations.append("Итоговую интерпретацию лучше подтверждать дополнительным наблюдением: часть контрольных индикаторов внимания снижает надёжность данных.")
    if social_desirability_index > 70:
        recommendations.append("Полезно добавить короткое живое интервью по кейсам: ответы частично склонны к социально желательной подаче.")
    if not recommendations:
        recommendations.append("Подходит для следующего этапа оценки через практическую задачу, короткий разбор решения и обратную связь от наставника.")

    level_text = profile_level_text(overall_potential)
    summary_text = (
        f"{player_name} показал(а) {level_text} общий потенциал для стажировки. "
        f"По ЭМП сильнее всего выражены {', '.join(top_emp) if top_emp else 'ключевые личностные шкалы'}. "
        f"Среди когнитивных качеств выделяются {', '.join(top_cog) if top_cog else 'когнитивные навыки решения задач'}. "
        f"Игровая точность составила {cognitive_accuracy:.1f}%, индекс скорости — {speed_index:.1f}/100."
    )

    badges = build_player_badges(rank_map.get(player_id), overall_potential, cognitive_accuracy, speed_index, attention_pass_rate)

    return {
        "playerId": player_id,
        "playerName": player_name,
        "score": player_row.get("score", 0),
        "rank": rank_map.get(player_id),
        "overallPotential": overall_potential,
        "summaryText": summary_text,
        "fitTags": fit_tags,
        "badges": badges,
        "strengths": strengths,
        "growthZones": growth_zones,
        "recommendations": recommendations,
        "empRadar": emp_radar,
        "cognitiveRadar": cognitive_radar,
        "quality": {
            "attentionPassRate": attention_pass_rate,
            "socialDesirabilityIndex": social_desirability_index,
            "dataQualityIndex": data_quality_index,
        },
        "gameMetrics": {
            "rank": rank_map.get(player_id),
            "cognitiveAccuracy": cognitive_accuracy,
            "avgCognitiveTimeMs": avg_cognitive_time,
            "speedIndex": speed_index,
            "cognitiveTasks": cognitive_total,
        },
        "history": history_rows,
    }


def compute_reports_for_room(room_code: str) -> dict:
    room_results = db_room_results(room_code)
    players = sorted(room_results.get("players", []), key=lambda x: (-int(x.get("score", 0)), str(x.get("name", ""))))
    rank_map = {player.get("playerId"): idx + 1 for idx, player in enumerate(players)}
    answers_by_player: Dict[str, List[dict]] = defaultdict(list)
    for ans in room_results.get("answers", []) or []:
        answers_by_player[ans.get("playerId")].append(ans)
    meta_by_key = _question_meta_map(room_results)

    profiles = []
    for player in players:
        profile = _build_player_report(player, answers_by_player.get(player.get("playerId"), []), meta_by_key, rank_map)
        profiles.append(profile)
        db_player_report_upsert(room_code, profile["playerId"], profile["playerName"], profile)

    avg_score = round(_mean([float(p.get("score", 0)) for p in profiles], default=0.0), 1) if profiles else 0.0
    avg_accuracy = round(_mean([float((p.get("gameMetrics") or {}).get("cognitiveAccuracy", 0.0)) for p in profiles], default=0.0), 1) if profiles else 0.0
    avg_potential = round(_mean([float(p.get("overallPotential", 0.0)) for p in profiles], default=0.0), 1) if profiles else 0.0

    tag_counter = Counter()
    for profile in profiles:
        for tag in profile.get("fitTags", []) or []:
            tag_counter[str(tag)] += 1
    top_tags = [{"tag": tag, "count": count} for tag, count in tag_counter.most_common(8)]

    def avg_radar(key_name: str) -> List[dict]:
        values: Dict[str, List[float]] = defaultdict(list)
        labels: Dict[str, str] = {}
        for profile in profiles:
            for item in profile.get(key_name, []) or []:
                values[item.get("key")].append(float(item.get("value", 0.0)))
                labels[item.get("key")] = item.get("label")
        out = []
        for key, vals in values.items():
            out.append({"key": key, "label": labels.get(key, key), "value": round(_mean(vals, default=0.0), 1)})
        return out

    dashboard = {
        "roomCode": room_code,
        "summary": {
            "playersCount": len(profiles),
            "avgScore": avg_score,
            "avgAccuracy": avg_accuracy,
            "avgPotential": avg_potential,
            "topTags": top_tags,
        },
        "roomRadar": {
            "emp": avg_radar("empRadar"),
            "cognitive": avg_radar("cognitiveRadar"),
        },
        "players": profiles,
    }
    db_room_report_upsert(room_code, dashboard)
    return dashboard


def build_and_store_reports(room_code: str) -> dict:
    return compute_reports_for_room(room_code)


def _csv_response(filename: str, rows: List[Dict[str, Any]], fieldnames: List[str]) -> Response:
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        safe_row = {}
        for field in fieldnames:
            value = row.get(field, "")
            if isinstance(value, (dict, list)):
                value = json.dumps(value, ensure_ascii=False)
            safe_row[field] = value
        writer.writerow(safe_row)
    return Response(
        buf.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def build_hr_export_rows(dashboard: dict) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for profile in dashboard.get("players", []) or []:
        quality = profile.get("quality") or {}
        game = profile.get("gameMetrics") or {}
        rows.append(
            {
                "roomCode": dashboard.get("roomCode"),
                "playerId": profile.get("playerId"),
                "playerName": profile.get("playerName"),
                "rank": game.get("rank"),
                "score": profile.get("score"),
                "overallPotential": profile.get("overallPotential"),
                "cognitiveAccuracyPct": game.get("cognitiveAccuracy"),
                "avgCognitiveTimeMs": game.get("avgCognitiveTimeMs"),
                "speedIndex": game.get("speedIndex"),
                "attentionPassRate": quality.get("attentionPassRate"),
                "socialDesirabilityIndex": quality.get("socialDesirabilityIndex"),
                "dataQualityIndex": quality.get("dataQualityIndex"),
                "badges": _flatten_tags(profile.get("badges", [])),
                "fitTags": _flatten_tags(profile.get("fitTags", [])),
                "strengths": _flatten_tags(profile.get("strengths", [])),
                "growthZones": _flatten_tags(profile.get("growthZones", [])),
                "recommendations": _flatten_tags(profile.get("recommendations", [])),
                "summaryText": profile.get("summaryText"),
            }
        )
    return rows


def build_hr_html_report(dashboard: dict) -> str:
    summary = dashboard.get("summary") or {}
    players_html = []
    for profile in dashboard.get("players", []) or []:
        quality = profile.get("quality") or {}
        game = profile.get("gameMetrics") or {}
        players_html.append(
            f"""
        <section class="player">
          <h2>{html_lib.escape(str(profile.get('playerName', 'Игрок')))} <span class="rank">#{game.get('rank', '—')}</span></h2>
          <p class="summary">{html_lib.escape(str(profile.get('summaryText', '')))}</p>
          <div class="metrics">
            <div><b>Потенциал:</b> {profile.get('overallPotential', '—')}</div>
            <div><b>Очки:</b> {profile.get('score', '—')}</div>
            <div><b>Точность:</b> {game.get('cognitiveAccuracy', '—')}%</div>
            <div><b>Скорость:</b> {game.get('speedIndex', '—')}/100</div>
            <div><b>Контроль внимания:</b> {quality.get('attentionPassRate', '—')}%</div>
            <div><b>Соц. желательность:</b> {quality.get('socialDesirabilityIndex', '—')}/100</div>
          </div>
          <div class="chips">{''.join(f'<span>{html_lib.escape(str(tag))}</span>' for tag in (profile.get('fitTags') or []))}</div>
          <div class="chips">{''.join(f'<span>{html_lib.escape(str(tag))}</span>' for tag in (profile.get('badges') or []))}</div>
          <div class="cols">
            <div><h3>Сильные стороны</h3><ul>{''.join(f'<li>{html_lib.escape(str(x))}</li>' for x in (profile.get('strengths') or []))}</ul></div>
            <div><h3>Зоны роста</h3><ul>{''.join(f'<li>{html_lib.escape(str(x))}</li>' for x in (profile.get('growthZones') or []))}</ul></div>
            <div><h3>Рекомендации</h3><ul>{''.join(f'<li>{html_lib.escape(str(x))}</li>' for x in (profile.get('recommendations') or []))}</ul></div>
          </div>
        </section>
        """
        )
    return f"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><title>EMOPOT HR report {html_lib.escape(str(dashboard.get('roomCode', '')))}</title>
<style>body{{font-family:Inter,Arial,sans-serif;background:#f8fafc;color:#0f172a;margin:0;padding:24px}}h1{{margin:0 0 8px}}.card{{background:#fff;border:1px solid #e2e8f0;border-radius:18px;padding:18px;margin:0 0 16px;box-shadow:0 10px 30px rgba(15,23,42,.06)}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}}.stat{{background:#f8fafc;border-radius:14px;padding:12px;border:1px solid #e5e7eb}}.player{{background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:18px;margin-top:16px}}.rank{{color:#2563eb}}.summary{{line-height:1.6}}.metrics{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin:12px 0}}.chips{{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0}}.chips span{{background:#eef2ff;border:1px solid #c7d2fe;border-radius:999px;padding:6px 10px;font-weight:700;color:#312e81}}.cols{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}}ul{{margin:8px 0 0;padding-left:18px}}@media(max-width:900px){{.cols{{grid-template-columns:1fr}}}}</style></head><body>
<div class="card">
<h1>EMOPOT — HR-отчёт по комнате {html_lib.escape(str(dashboard.get('roomCode', '')))}</h1>
<p>Игроков: <b>{summary.get('playersCount', 0)}</b>. Средний балл: <b>{summary.get('avgScore', 0)}</b>. Средняя точность: <b>{summary.get('avgAccuracy', 0)}%</b>. Средний потенциал: <b>{summary.get('avgPotential', 0)}/100</b>.</p>
<div class="grid">
<div class="stat"><div>Топ-теги</div><div>{html_lib.escape(', '.join([str(item.get('tag')) for item in (summary.get('topTags') or [])])) or '—'}</div></div>
</div>
</div>
{''.join(players_html)}
</body></html>"""


# ====================== FastAPI ======================
app = FastAPI(title="EMOPOT — локальный сервер")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.on_event("startup")
def on_startup():
    db_init()


@app.get("/", response_class=HTMLResponse)
def root():
    return FileResponse(APP_DIR / "index.html")


@app.get("/admin", response_class=HTMLResponse)
def admin_landing():
    return FileResponse(STATIC_DIR / "admin.html")


@app.get("/api/tasks")
def api_tasks():
    return JSONResponse(task_counts())


@app.post("/api/tasks/reload")
def api_tasks_reload():
    global RAW_TASKS, TASK_BANK, CATEGORIES, TASK_BY_ID
    RAW_TASKS = load_tasks_raw()
    TASK_BANK = transform_tasks(RAW_TASKS)
    CATEGORIES = list(TASK_BANK.keys())
    TASK_BY_ID = {q["id"]: q for q in TASK_BANK.values() for q in q}
    return JSONResponse({"ok": True, **task_counts()})


@app.get("/api/room/{code}/results")
def api_room_results(code: str):
    code = code.upper()
    if code not in ROOMS and not exists_in_db(code=code):
        return JSONResponse({"error": "room not found"}, status_code=404)
    return JSONResponse(db_room_results(code))


def exists_in_db(code: str) -> bool:
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("SELECT 1 FROM rooms WHERE code=?", (code,))
    row = cur.fetchone()
    con.close()
    return bool(row)


@app.get("/api/export/{code}/player/{player_id}.csv")
def export_player_csv(code: str, player_id: str):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute(
        """
        SELECT round_no, question_id, category, block, instrument, item_type, answer_text, answer_choice, is_correct, awarded, scored_value, time_spent_ms
        FROM answers WHERE room_code=? AND player_id=? ORDER BY round_no
    """,
        (code.upper(), player_id),
    )
    rows = cur.fetchall()
    con.close()
    if not rows:
        return PlainTextResponse("Нет данных", status_code=404)
    header = "round,questionId,category,block,instrument,itemType,answerText,answerChoice,isCorrect,awarded,scoredValue,timeMs\n"

    def fmt(x: Any) -> str:
        s = "" if x is None else str(x)
        return s.replace(",", " ")

    body = "\n".join(",".join(map(fmt, r)) for r in rows)
    content = header + body + "\n"
    return Response(
        content,
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{code.upper()}_{player_id}.csv"'},
    )


@app.get("/api/export/{code}/room.csv")
def export_room_csv(code: str):
    data = db_room_results(code.upper())
    header = "playerId,name,score\n"
    body = "\n".join(f'{p["playerId"]},{p["name"]},{p["score"]}' for p in data["players"])
    content = header + body + "\n"
    return Response(
        content,
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{code.upper()}_summary.csv"'},
    )


@app.get("/api/room/{code}/admin-report")
def api_room_admin_report(code: str):
    code = code.upper()
    dashboard = db_room_report_get(code)
    if dashboard is None:
        if not exists_in_db(code):
            return JSONResponse({"error": "room not found"}, status_code=404)
        dashboard = build_and_store_reports(code)
    return JSONResponse(dashboard)


@app.get("/api/room/{code}/player/{player_id}/report")
def api_player_report(code: str, player_id: str):
    code = code.upper()
    profile = db_player_report_get(code, player_id)
    if profile is None:
        if not exists_in_db(code):
            return JSONResponse({"error": "room not found"}, status_code=404)
        build_and_store_reports(code)
        profile = db_player_report_get(code, player_id)
    if profile is None:
        return JSONResponse({"error": "player report not found"}, status_code=404)
    return JSONResponse(profile)


@app.get("/api/export/{code}/hr-report.csv")
def export_hr_report_csv(code: str):
    code = code.upper()
    dashboard = build_and_store_reports(code)
    rows = build_hr_export_rows(dashboard)
    fieldnames = [
        "roomCode", "playerId", "playerName", "rank", "score", "overallPotential",
        "cognitiveAccuracyPct", "avgCognitiveTimeMs", "speedIndex", "attentionPassRate",
        "socialDesirabilityIndex", "dataQualityIndex", "badges", "fitTags", "strengths",
        "growthZones", "recommendations", "summaryText",
    ]
    return _csv_response(f"{code}_hr_report.csv", rows, fieldnames)


@app.get("/api/export/{code}/hr-report.json")
def export_hr_report_json(code: str):
    code = code.upper()
    dashboard = build_and_store_reports(code)
    return Response(
        json.dumps(dashboard, ensure_ascii=False, indent=2),
        media_type="application/json; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{code}_hr_report.json"'},
    )


@app.get("/api/export/{code}/hr-report.html")
def export_hr_report_html(code: str):
    code = code.upper()
    dashboard = build_and_store_reports(code)
    html_text = build_hr_html_report(dashboard)
    return Response(
        html_text,
        media_type="text/html; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{code}_hr_report.html"'},
    )


@app.get("/api/export/{code}/player/{player_id}/profile.json")
def export_player_profile_json(code: str, player_id: str):
    code = code.upper()
    profile = db_player_report_get(code, player_id)
    if profile is None:
        build_and_store_reports(code)
        profile = db_player_report_get(code, player_id)
    if profile is None:
        return PlainTextResponse("Нет данных", status_code=404)
    return Response(
        json.dumps(profile, ensure_ascii=False, indent=2),
        media_type="application/json; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{code}_{player_id}_profile.json"'},
    )


# ====================== WebSocket ======================
@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            raw = await ws.receive_text()
            msg = json.loads(raw)
            t = msg.get("type")

            if t == "admin_create_room":
                code = (msg.get("preferredCode") or gen_code()).upper()
                if code in ROOMS:
                    code = gen_code()

                assessment_mode = resolve_assessment_mode(msg.get("assessmentMode"), msg.get("taskFilterMode"))
                block_config = sanitize_block_config(msg.get("blockConfig"), fallback_mode=assessment_mode)

                room = Room(
                    code=code,
                    rounds=int(msg.get("rounds", 6)),
                    assessment_mode=assessment_mode,
                    block_config=block_config,
                )
                ROOMS[code] = room
                room.admin = ws
                CLIENT_TO_ROOM[ws] = code
                db_room_upsert(code, room.rounds, "lobby", room.assessment_mode, room.block_config)
                await ws.send_json(
                    {
                        "type": "room_created",
                        "roomCode": code,
                        "assessmentMode": room.assessment_mode,
                        "blockConfig": room.block_config,
                    }
                )
                continue

            if t == "admin_attach":
                code = msg["roomCode"].upper()
                room = ROOMS.get(code)
                if not room:
                    await ws.send_json({"type": "error", "message": "Комната не найдена"})
                    continue
                room.admin = ws
                CLIENT_TO_ROOM[ws] = code
                await ws.send_json(
                    {
                        "type": "room_attached",
                        "roomCode": code,
                        "players": room.snapshot_players(),
                        "status": room.status,
                        "assessmentMode": room.assessment_mode,
                        "blockConfig": room.block_config,
                    }
                )
                continue

            if t == "join":
                code = msg["roomCode"].upper()
                name = str(msg.get("playerName", "Игрок")).strip()[:32]
                room = ROOMS.get(code)
                if not room:
                    await ws.send_json({"type": "error", "message": "Комната не найдена"})
                    continue
                if room.status != "lobby":
                    await ws.send_json({"type": "error", "message": "Игра уже идёт"})
                    continue
                if len(room.players) >= 10:
                    await ws.send_json({"type": "error", "message": "Комната заполнена"})
                    continue
                pid = msg.get("playerId") or ("p_" + "".join(random.choices(string.ascii_lowercase + string.digits, k=8)))
                pc = PlayerConn(ws=ws, id=pid, name=name)
                room.players[pid] = pc
                CLIENT_TO_ROOM[ws] = code
                db_player_upsert(room.code, pid, name, 0)
                await ws.send_json({"type": "joined", "roomCode": code, "playerId": pid, "players": room.snapshot_players()})
                await broadcast(code, {"type": "players", "players": room.snapshot_players()})
                continue

            if t == "admin_start":
                code = msg["roomCode"].upper()
                room = ROOMS.get(code)
                if not room or room.admin is not ws:
                    await ws.send_json({"type": "error", "message": "Нет прав/комната не найдена"})
                    continue
                if len(room.players) == 0:
                    await ws.send_json({"type": "error", "message": "Нет игроков"})
                    continue

                if should_use_full_session_plan(room.assessment_mode):
                    room.session_plan = build_session_plan(room)
                    if not room.session_plan:
                        await ws.send_json({"type": "error", "message": "Не удалось собрать сценарий из доступных задач"})
                        continue
                    room.rounds = len(room.session_plan)
                else:
                    room.session_plan = []

                room.status = "running"
                db_room_upsert(code, room.rounds, "running", room.assessment_mode, room.block_config)
                await broadcast(code, {"type": "game_started", "rounds": room.rounds})
                asyncio.create_task(run_rounds(room))
                continue

            if t == "answer":
                code = msg["roomCode"].upper()
                room = ROOMS.get(code)
                if not room:
                    continue
                pid = msg.get("playerId")
                pc = room.players.get(pid)
                if not pc or room.status != "running" or room.current_question is None:
                    continue
                if pc.answered:
                    continue
                now = time.time()
                if now > room.round_deadline:
                    continue

                q = room.current_question
                if q["type"] == "mcq":
                    ch = msg.get("choice")
                    try:
                        pc.ans_choice = int(ch) if ch is not None else None
                    except Exception:
                        pc.ans_choice = None
                    pc.ans_text = ""
                else:
                    pc.ans_text = str(msg.get("text", ""))[:300]
                    pc.ans_choice = None

                spent_ms = int((now - (room.round_deadline - room.time_limit)) * 1000)
                pc.ans_time_ms = max(0, spent_ms)
                pc.answered = True

                if all(p.answered for p in room.players.values()):
                    if room.timer_task and not room.timer_task.done():
                        room.timer_task.cancel()
                    await finish_round(room)
                continue

            if t == "admin_end":
                code = msg["roomCode"].upper()
                room = ROOMS.get(code)
                if room and room.admin is ws:
                    room.status = "finished"
                    room.current_question = None

                    if room.timer_task and not room.timer_task.done():
                        room.timer_task.cancel()

                    db_room_upsert(code, room.rounds, "finished", room.assessment_mode, room.block_config)

                    dashboard = None
                    try:
                        dashboard = build_and_store_reports(code)
                    except Exception:
                        traceback.print_exc()

                    await broadcast(
                        code,
                        {
                            "type": "final",
                            "scores": room.snapshot_players(),
                            "reportsReady": bool(dashboard),
                            "playersCount": len((dashboard or {}).get("players", [])),
                        },
                    )
                continue

    except WebSocketDisconnect:
        pass
    finally:
        code = CLIENT_TO_ROOM.get(ws)
        if code:
            room = ROOMS.get(code)
            if room:
                if room.admin is ws:
                    room.admin = None
                drop_pid = None
                for pid, pc in list(room.players.items()):
                    if pc.ws is ws:
                        drop_pid = pid
                        break
                if drop_pid:
                    del room.players[drop_pid]
                    await safe_broadcast(code, {"type": "players", "players": room.snapshot_players()})
            CLIENT_TO_ROOM.pop(ws, None)


# ====================== game loop ======================
async def run_rounds(room: Room):
    room.used_ids = set()

    block_config = room.block_config or sanitize_block_config(None, fallback_mode=room.assessment_mode)

    has_card = any(q.get("mode", "base") == "card" and _allowed_by_block_config(q, block_config) for q in _all_tasks())
    has_non_card = any(q.get("mode", "base") != "card" and _allowed_by_block_config(q, block_config) for q in _all_tasks())

    plan = room.session_plan if room.session_plan else None
    total_rounds = len(plan) if plan else room.rounds
    room.rounds = total_rounds

    try:
        for r in range(1, total_rounds + 1):
            if room.status != "running":
                break

            room.current_round = r

            if plan:
                q = plan[r - 1]
            else:
                if room.assessment_mode == "cards_only":
                    desired_mode = "card"
                elif has_card and has_non_card:
                    desired_mode = "card" if r % 2 == 0 else "non_card"
                elif has_card:
                    desired_mode = "card"
                else:
                    desired_mode = "non_card"

                q = pick_question(room.used_ids, desired_mode=desired_mode, block_config=block_config)
                room.used_ids.add(q["id"])

            room.current_question = q
            db_round_question_upsert(room.code, r, q)

            for p in room.players.values():
                p.answered = False
                p.ans_text = ""
                p.ans_choice = None
                p.ans_time_ms = 0

            tl = int(q.get("timeRef") or random.randint(40, 60))
            room.time_limit = tl
            room.round_deadline = time.time() + tl

            payload = {
                "type": "question",
                "round": r,
                "totalRounds": room.rounds,
                "category": q["category"],
                "block": task_block(q),
                "instrument": task_instrument(q),
                "itemType": task_item_type(q),
                "responseModel": infer_response_model(q),
                "questionId": q["id"],
                "timeLimit": tl,
                "qtype": q["type"],
                "prompt": q["prompt"],
                "mode": q.get("mode", "base"),
                "subtype": q.get("subtype"),
            }
            if q["type"] == "mcq":
                payload["options"] = q.get("options", [])

            await broadcast(room.code, payload)

            async def timer():
                try:
                    await asyncio.sleep(tl)
                    await finish_round(room)
                except asyncio.CancelledError:
                    pass

            room.timer_task = asyncio.create_task(timer())

            while room.current_question is not None and room.status == "running":
                await asyncio.sleep(0.1)

    except Exception:
        traceback.print_exc()

    finally:
        room.current_question = None

        if room.timer_task and not room.timer_task.done():
            room.timer_task.cancel()

        if room.status == "running":
            room.status = "finished"
            db_room_upsert(room.code, room.rounds, "finished", room.assessment_mode, room.block_config)

        dashboard = None
        try:
            dashboard = build_and_store_reports(room.code)
        except Exception:
            traceback.print_exc()

        await broadcast(
            room.code,
            {
                "type": "final",
                "scores": room.snapshot_players(),
                "reportsReady": bool(dashboard),
                "playersCount": len((dashboard or {}).get("players", [])),
            },
        )


async def finish_round(room: Room):
    if room.current_question is None:
        return
    q = room.current_question
    mode = q.get("mode", "base")
    subtype = q.get("subtype")
    response_model = infer_response_model(q)
    block = task_block(q)
    instrument = task_instrument(q)
    item_type = task_item_type(q)
    survey_item = is_assessment_task(q)
    results = []

    for p in room.players.values():
        if survey_item:
            has_answer = (p.ans_choice is not None) or bool((p.ans_text or "").strip())
            scored_value = compute_scored_value(q, p.ans_text, p.ans_choice)
            if is_control_task(q):
                expected_choice = q.get("expectedChoice")
                if expected_choice is None and q.get("correctIndex") is not None:
                    expected_choice = q.get("correctIndex")
                ok = evaluate_expected_choice(expected_choice, p.ans_choice) if q.get("type") == "mcq" else bool((p.ans_text or "").strip())
                status_text = "пройден" if ok else ("провален" if ok is False else "получен")
            else:
                ok = None
                status_text = "получен" if has_answer else "нет ответа"
            awarded = 0
        else:
            scored_value = None
            if mode == "card" and subtype == "robot_pair_to_target":
                ok = _check_robot_pair_to_target(p.ans_text)
            elif mode == "card" and subtype == "word_ladder_lisa_nora":
                ok = _check_word_ladder_lisa_nora(p.ans_text)
            elif mode == "card" and subtype == "clock_equal_sums":
                ok = _check_clock_equal_sums(p.ans_text)
            else:
                if q["type"] == "mcq":
                    ok = (p.ans_choice is not None) and (int(p.ans_choice) == int(q.get("correctIndex", -1)))
                else:
                    ok = _is_correct_text(p.ans_text, q.get("accept", []))
            awarded = 1 if ok else 0
            status_text = "верно" if ok else "неверно"

        p.score += awarded

        db_player_upsert(room.code, p.id, p.name, p.score)
        db_answer_add(
            room.code,
            room.current_round,
            q["id"],
            q["category"],
            block,
            instrument,
            item_type,
            p.id,
            p.name,
            p.ans_text,
            p.ans_choice,
            ok,
            awarded,
            scored_value,
            p.ans_time_ms,
        )
        results.append(
            {
                "playerId": p.id,
                "name": p.name,
                "choice": p.ans_choice,
                "text": p.ans_text,
                "isCorrect": ok,
                "statusText": status_text,
                "awarded": awarded,
                "scoredValue": scored_value,
                "timeMs": p.ans_time_ms,
                "score": p.score,
            }
        )

    reveal = {
        "type": "reveal",
        "round": room.current_round,
        "questionId": q["id"],
        "category": q["category"],
        "block": block,
        "instrument": instrument,
        "itemType": item_type,
        "responseModel": response_model,
        "qtype": q["type"],
        "prompt": q["prompt"],
        "mode": mode,
        "subtype": subtype,
        "results": results,
        "scores": room.snapshot_players(),
    }
    if q["type"] == "mcq":
        reveal["options"] = q.get("options", [])
        reveal["correctIndex"] = q.get("correctIndex")
        if q.get("options") and q.get("correctIndex") is not None:
            ci = q.get("correctIndex", -1)
            if 0 <= ci < len(q["options"]):
                reveal["correctText"] = q["options"][ci]
            else:
                reveal["correctText"] = None
        else:
            reveal["correctText"] = None
    else:
        acc = q.get("accept", [])
        reveal["accepted"] = acc
        reveal["correctText"] = acc[0] if acc else ""

    await broadcast(room.code, reveal)
    room.current_question = None


async def broadcast(room_code: str, payload: dict):
    await safe_broadcast(room_code, payload)


async def safe_broadcast(room_code: str, payload: dict):
    room = ROOMS.get(room_code)
    if not room:
        return
    dead = []
    if room.admin:
        try:
            await room.admin.send_json(payload)
        except Exception:
            dead.append(room.admin)
    for pc in list(room.players.values()):
        try:
            await pc.ws.send_json(payload)
        except Exception:
            dead.append(pc.ws)
    for ws in dead:
        CLIENT_TO_ROOM.pop(ws, None)


@app.get("/healthz")
def health():
    return {"ok": True}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "server:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
    )
